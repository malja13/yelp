//node_modules/.bin/eslint ./test/pageobjects/*.js ./test/specs/*.js --fix

npm install
npm run test