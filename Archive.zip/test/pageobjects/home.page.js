// home.page.js
const Page = require('./page');
const Selector = require('../selectors');

const HomePage = Object.create(Page, {
  /**
     * define elements
     */
  logo: { get() { return browser.element(Selector.HomePage.selectors.logo); } },
  find: { get() { return browser.element(Selector.HomePage.selectors.boxFind); } },
  optRest: { get() { return browser.element(Selector.HomePage.selectors.dropRest); } },

  /**
     * define or overwrite page methods
     */
  open: { value() {
    Page.open.call(this, '');
  } },
  submit: { value() {
    this.form.submitForm();
  } },
  click: { value() {
    this.optRest.waitForEnabled(3000);
    this.optRest.click();
  } },

});
module.exports = HomePage;