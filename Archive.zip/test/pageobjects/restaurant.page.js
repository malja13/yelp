// restaurant.page.js
var Page = require('./page')
const Selector = require('../selectors');

var HomePage = Object.create(Page, {
    /**
     * define elements
     */
    name:    { get: function () { return browser.element('.u-space-t1 h1'); } },
    phone: { get: function () { return browser.element('.biz-phone');} },
    siteDetail: { get: function () { return browser.element('.rating-details');} },
    review: { get: function () { return browser.elements('.review-highlights-list .quote');} },
    btnReview: { get: function () { return browser.element('a.ybtn.ybtn--primary.war-button');} },
    
    /**
     * define or overwrite page methods
     */
    open: { value: function() {
        Page.open.call(this, '');
    } },
    submit: { value: function() {
        this.form.submitForm();
    } },


});
module.exports = HomePage;