// search.page.js
var Page = require('./page')
const Selector = require('../selectors')
const TIME = require('../timers')

var SearchPage = Object.create(Page, {
    /**
     * define elements
     */
    content:    { get: function () { return browser.element(Selector.SearchPage.selectors.content); } },
    find: { get: function() { return browser.element(Selector.SearchPage.selectors.find)}},
    listSearchResult: { get: function() { return browser.elements(Selector.SearchPage.selectors.searchResult)}},
    
    filter: { get: function() { return browser.element(Selector.SearchPage.selectors.filter)}},
    btnAllFilter: { get: function() { return browser.element(Selector.SearchPage.selectors.btnAllFilter)}},
    listStars: { get: function() { return browser.elements(Selector.SearchPage.selectors.listStars)}},   
    first: { get: function() { return browser.element(Selector.SearchPage.xpath.firtElement)}},

    /**
     * define or overwrite page methods
     */
    open: { value: function() {
        Page.open.call(this, '');
    } },
    submit: { value: function() {
        this.form.submitForm();
    } },


    place: { value: function(param, value){ 
        
        var xpath = '//*[text()="' + param + '"]/../ul/li/label/span[contains(text(),"' + value+'")]';

        browser.waitForEnabled(xpath, TIME.TIME_WAIT_ELEMENT);
        browser.isSelected(xpath);
        browser.click(xpath);
        browser.waitForEnabled(Selector.SearchPage.selectors.circleSpinner, TIME.TIME_WAIT_LOAD);

    } },

    selectFirts: { value: function() {     
        browser.waitForEnabled(Selector.SearchPage.selectors.selectionFirst, TIME.TIME_WAIT_LOAD);
        browser.element(Selector.SearchPage.selectors.selectionFirst).click();
    } },

});
module.exports = SearchPage;
