// searchrestaurant.js
const expect = require('chai').expect;
const HomePage = require('../pageobjects/home.page');
const SearchPage = require('../pageobjects/search.page');
// const RestaurantPage = require('../pages/search.page');
const Data = require('../data/input');
const TIME = require('../timers');


describe('Search Restaurant', () => {
  it('Search list of Restaurants', () => {
    HomePage.open();
    HomePage.logo.waitForEnabled();
    expect(HomePage.logo.getText()).to.contain('Yelp');

    //Search Restaurant
    HomePage.find.click();
    HomePage.optRest.waitForEnabled(TIME.TIME_WAIT_ELEMENT);
    HomePage.optRest.click();
    expect(SearchPage.content.getText()).to.contain('Best Restaurants');

    // Append Pizza to Restaurants to make the search text as “Restaurants Pizza”
    SearchPage.find.setValue(SearchPage.find.getValue() + ' ' + 'Pizza');

    var list = SearchPage.listSearchResult.value.length;
    //console.log('Report total no. of Search ' + list);

    SearchPage.btnAllFilter.waitForEnabled(TIME.TIME_WAIT_ELEMENT);
    SearchPage.btnAllFilter.click();

    SearchPage.filter.waitForEnabled(TIME.TIME_WAIT_ELEMENT);

    expect(SearchPage.filter.getText()).to.contain('Sort By');
    
    SearchPage.place(Data.filter.typeFilter[0],Data.filter.optFilter[0]);
    SearchPage.filter.waitForEnabled(TIME.TIME_WAIT_ELEMENT);

    list = SearchPage.listSearchResult.value.length;
    //console.log('Report total no. of Search ' + list);

    //console.log(SearchPage.listStars.value.map(function(el) { 
    //    return el.getAttribute('alt'); }));

    SearchPage.first.click();

    //expect(RestaurantPage.btnReview.getText()).to.contain('Write a Review');

    /*    console.log(RestaurantPage.name.getText());
        console.log(RestaurantPage.phone.getText());
        console.log(SearchPage.review.value.map(function(el) { 
            return el.getText(); })); */
  });
});
